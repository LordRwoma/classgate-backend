<div x-data="{ step: 1 }" class="max-w-4xl mx-auto py-10">
    <div class="flex items-center justify-between mb-10">
        <div class="flex-1 h-2 bg-blue-600 rounded-full"></div>
        <div class="px-4 text-blue-600 font-bold uppercase">Langkah <span x-text="step"></span> dari 3</div>
        <div class="flex-1 h-2 bg-gray-200 rounded-full"></div>
    </div>

    <div x-show="step === 1" class="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
        <h2 class="text-2xl font-bold mb-6">Pilih Konteks Materi</h2>
        <select class="w-full p-4 border rounded-xl mb-4">
            <option>Pilih Fase & Kelas</option>
            <option>Fase D - Kelas 7</option>
        </select>
        <button @click="step = 2" class="w-full py-4 bg-blue-600 text-white rounded-xl hover:bg-blue-700">Lanjut</button>
    </div>

    <div x-show="step === 2" class="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
        <h2 class="text-2xl font-bold mb-6">Instruksi Spesifik</h2>
        <textarea class="w-full p-4 border rounded-xl h-40" placeholder="Apa yang ingin kamu buat hari ini?"></textarea>
        <div class="flex gap-4 mt-6">
            <button @click="step = 1" class="w-1/3 py-4 border rounded-xl">Kembali</button>
            <button @click="step = 3" class="w-2/3 py-4 bg-blue-600 text-white rounded-xl">Generate AI</button>
        </div>
    </div>
</div>

<script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>